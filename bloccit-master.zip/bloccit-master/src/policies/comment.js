const ApplicationPolicy = require("./application");

module.exports = class CommentPolicy extends ApplicationPolicy {

}